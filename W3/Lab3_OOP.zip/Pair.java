public class Pair {
    private double a;
    private double b;
    
    public Pair(double a,double b){
        this.a = a;
        this.b = b;
    }

    public void setA(double a){
        this.a = a;
    }

    public double getA(){
        return this.a;
    }

    public void setB(double b){
        this.b =b;
    }

    public double getB(){
        return this.b;
    }
}
