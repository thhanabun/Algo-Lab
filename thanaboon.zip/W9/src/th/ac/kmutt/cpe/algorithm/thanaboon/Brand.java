package th.ac.kmutt.cpe.algorithm.thanaboon;

public class Brand {
    int t;
    int v;
    public Brand(int t,int v){
        this.t = t;
        this.v = v; 
    }
}
